package com.example.authsystem.web.dto.ResponseDto;

public class OtpResponseDto {

    private boolean success;

    public OtpResponseDto(boolean success) {
        this.success = success;
    }

    // Getters and Setters
}
